//
//  CustomModuleImp.h
//  CustomModuleImp
//
//  Created by Aleksandr Basalaev on 22.08.2024.
//  Copyright © 2024 Sportmaster Ooo. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CustomModuleImp.
FOUNDATION_EXPORT double CustomModuleImpVersionNumber;

//! Project version string for CustomModuleImp.
FOUNDATION_EXPORT const unsigned char CustomModuleImpVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CustomModuleImp/PublicHeader.h>


